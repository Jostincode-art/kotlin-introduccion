fun main(args: Array<String>) {

    val c: Char = '1'
    val d: Char = '2'

    println("Resultado c+d = " + c + d)

    val mensaje: String = "Hola Mundo"
    val nombre = "María"
    val anyoNacimiento = 1990
    val anyoActual = 2020

    println("Nombre: $nombre tiene ${anyoActual - anyoNacimiento} años")
}
