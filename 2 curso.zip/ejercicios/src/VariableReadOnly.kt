
fun main(args: Array<String>){
    val mensaje="Mundo"
    val mensajecompleto="Hola " + mensaje

    println(mensajecompleto)
    //no es posible modificar su valor
    //mensaje completo = "otro mensaje"
}