package curso2.kotlin

fun main() {
    var a = 10
    var b = 3

    println(a + b)
    println(a - b)
    println(a * b)
    println(a / b)
    println(a % b)

    var c = 5
    println(c++)
    var x = 42
    println(x.toDouble())
    println(x.toString())

    var ch1 = '1'
    println(ch1.digitToInt())

    var ch2 = 'A'
    println(ch2.code)
}
